$(document).ready(function(){ 	
						   
						   
	// radius Box
	$('ul.fmenu li a').css({"border-bottom-right-radius": "6px", "-moz-border-radius-bottomright":"6px", "-webkit-border-bottom-right-radius":"6px", "border-bottom-left-radius":"6px", "-moz-border-radius-bottomleft":"6px", "	-webkit-border-bottom-left-radius":"6px"});
	$('.menu_nav ul li a').css({"border-top-right-radius": "6px", "-moz-border-radius-topright":"6px", "-webkit-border-top-right-radius":"6px", "border-top-left-radius":"6px", "-moz-border-radius-topleft":"6px", "	-webkit-border-top-left-radius":"6px"});
	$('a.com').css({"border-bottom-left-radius": "6px", "-moz-border-radius-bottomleft":"6px", "-webkit-border-bottom-left-radius":"6px", "border-top-left-radius":"6px", "-moz-border-radius-topleft":"6px", "	-webkit-border-top-left-radius":"6px"});
	// end radius Box
	 
});	